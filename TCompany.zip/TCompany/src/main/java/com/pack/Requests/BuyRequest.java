package com.pack.Requests;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BuyRequest {
    int subC;
}
