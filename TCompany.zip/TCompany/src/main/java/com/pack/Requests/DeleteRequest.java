package com.pack.Requests;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteRequest {
    public Long id;
}
